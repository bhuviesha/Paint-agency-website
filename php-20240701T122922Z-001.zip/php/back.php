<?php
require 'vendor/autoload.php'; // Include the PhpSpreadsheet library

use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

header('Content-Type: application/json');

// Check if the request is a POST request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    $name = $data['name'];
    $number = $data['number'];
    $email = $data['email'];

    // Open the Excel file (modify the path as needed)
    $filePath = 'customer_details.xlsx';

    // Create a new Spreadsheet if the file doesn't exist
    if (!file_exists($filePath)) {
        $spreadsheet = new Spreadsheet();
        $spreadsheet->getActiveSheet()
            ->fromArray(['Name', 'Number', 'Email'], null, 'A1');
    } else {
        // Load the existing Excel file
        $spreadsheet = IOFactory::load($filePath);
    }

    // Select the first worksheet
    $worksheet = $spreadsheet->getActiveSheet();

    // Find the next empty row
    $nextRow = $worksheet->getHighestRow() + 1;

    // Add customer details to the Excel sheet
    $worksheet->setCellValue('A' . $nextRow, $name);
    $worksheet->setCellValue('B' . $nextRow, $number);
    $worksheet->setCellValue('C' . $nextRow, $email);

    // Save the changes
    $writer = new Xlsx($spreadsheet);
    $writer->save($filePath);

    // Return a success response
    http_response_code(200);
    echo json_encode(['message' => 'Customer data stored successfully']);
} else {
    // Handle other HTTP request methods (e.g., GET) or invalid requests
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
}
